package com.techno.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.techno.POJO.StudentPojo;
import com.techno.Repository.StudRepository;

@Service
public class StudServices {
    
	@Autowired
	StudRepository repository;

	public StudentPojo AddStudent(String name, String email, long mobile, String address) {
		StudentPojo pojo=repository.addStudent(name,email,mobile,address);
		return pojo;
	}

	public StudentPojo searchStudent(int id) {
		StudentPojo pojo=repository.searchStudent(id);
		return pojo;
	}

	public StudentPojo removeStudent(int id) {
		StudentPojo pojo=repository.removeStudent(id);
		return pojo;
	}

	public List<StudentPojo> allStudent() {
		List<StudentPojo> students=repository.allStudent();
		return students;
	}

	public StudentPojo updateStudent(int id,String name, String email, long mob, String address) {
		StudentPojo pojo=repository.updateStudent(id,name,email,mob,address);
		return pojo;
	}

	
}
