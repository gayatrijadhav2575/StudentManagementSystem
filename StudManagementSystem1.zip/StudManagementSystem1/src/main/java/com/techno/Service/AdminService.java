package com.techno.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.techno.POJO.AdminPojo;
import com.techno.Repository.AdminRepository;

@Service
public class AdminService {
	@Autowired
  AdminRepository repository;

	public AdminPojo createAdmin(String username, String password) {
		AdminPojo admin=repository.createAdmin(username,password);
		return admin;
	}

	public AdminPojo login(String username, String password) {
		AdminPojo admin=repository.login(username,password);
		return admin;
	}

	public List<AdminPojo> getAdmin() {
		List<AdminPojo> admin=repository.getAdmin();
		return admin;
	}
}
