package com.techno.Controller;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.techno.POJO.AdminPojo;
import com.techno.Service.AdminService;



@Controller
public class AdminController {
	
    @Autowired
	AdminService service;
    
    @GetMapping("/logout")
    public String loginPage(ModelMap map, HttpSession session) {
    	session.invalidate();
    	map.addAttribute("msg","logged out sucessfully");
		return "Login";
	}
    
    
    @GetMapping("/createAdmin")
    public String createAdmin(ModelMap map) {
    	List<AdminPojo> admin=service.getAdmin();
    	if(admin.isEmpty()) {
    	return "createAdmin";
       }
    	map.addAttribute("msg","admin already present please login");
    	return "Login";
    }
    
    
    
    @PostMapping("/createAdmin")
    public String createAdminData(@RequestParam String username,@RequestParam String password,ModelMap map) {
    	AdminPojo admin=service.createAdmin(username,password);
    	if(admin!=null) {
    		map.addAttribute("msg","Admin created Successfully...");
    		return "Login";
    	}
    	map.addAttribute("msg","Admin not Created...");
    	return "createAdmin";
    }
    
    @PostMapping("/login")
    public String login(@RequestParam String username,@RequestParam String password,HttpSession session) {
    	AdminPojo admin=service.login(username,password);
    	if(admin!=null) {
    		session.setAttribute("login", admin);
    		session.setMaxInactiveInterval(30);
     return "Home";	
    }
    	return "Login";
    }
}
