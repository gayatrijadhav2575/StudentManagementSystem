package com.techno.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttribute;

import com.techno.POJO.AdminPojo;
import com.techno.POJO.StudentPojo;
import com.techno.Service.StudServices;


@Controller
public class StudController {
	@Autowired
	StudServices services;
	
	@GetMapping("/home")
  public String home(@SessionAttribute(value ="login", required = false)AdminPojo admin,ModelMap map) {
		if(admin!=null) {
			return "Home";
		}
		map.addAttribute("msg","Please Login First..!!!");
	  return "Login";
  }
	//add Page
	@GetMapping("/add")
	public String add(@SessionAttribute(value ="login", required = false)AdminPojo admin,ModelMap map) {
		if(admin!=null) {
			return "AddStudent";
		}
		map.addAttribute("msg","Please Login First..!!!");
	  return "Login";
	}
	
	//add StudentData
	@PostMapping("/add")
	public String AddStudent(@SessionAttribute(value="login",required = false)AdminPojo admin,@RequestParam String name, @RequestParam String email,@RequestParam long mobile,
			@RequestParam String address,ModelMap map){
	  StudentPojo pojo=services.AddStudent(name,email,mobile,address);
	  if(pojo!=null) {
		  map.addAttribute("msg","Data inserted Successfully..!");
		  return "AddStudent";
	  }
	  map.addAttribute("msg","Data not inserted Successfully..!");
	  return "AddStudent";	
	}
	
	//Search Page
	@GetMapping("/search")
	public String search(@SessionAttribute(value ="login", required = false)AdminPojo admin,ModelMap map) {
		if(admin!=null) {
			return "searchStudent";
		}
		map.addAttribute("msg","Please Login First..!!!");
	  return "Login";
	}
		
	
	//Search StudentData
	@PostMapping("/search")
	public String searchStudent(@SessionAttribute(value="login",required = false)AdminPojo admin,@RequestParam int id,ModelMap map) {
		StudentPojo pojo=services.searchStudent(id);
		if(pojo!=null) {
			map.addAttribute("msg","Data Exists");
			map.addAttribute("student",pojo);
			return "searchStudent";
		}
		map.addAttribute("msg","Data does not exists");
		return "searchStudent";
	}
	
	//Remove Page
	@GetMapping("/remove")
	public String remove(@SessionAttribute(value ="login", required = false)AdminPojo admin,ModelMap map) {
		if(admin!=null) {
			return "removeStudent";
		}
		map.addAttribute("msg","Please Login First..!!!");
	  return "Login";
	}
	
	
	//Remove StudentData
	@PostMapping("/remove")
	public String removeStudent(@SessionAttribute(value="login",required = false)AdminPojo admin,@RequestParam int id,ModelMap map) {
		StudentPojo pojo=services.removeStudent(id);
		if(pojo!=null) {
			List<StudentPojo>students =services.allStudent();
			map.addAttribute("students",students);
			map.addAttribute("msg","Data Removed");
			return "removeStudent";
		}
		map.addAttribute("msg","Data Not Removed");
		return "removeStudent";
	}
	
	//Update Page
	@GetMapping("/update")
	public String update(@SessionAttribute(value ="login", required = false)AdminPojo admin,ModelMap map) {
		if(admin!=null) {
			return "updateStudent";
		}
		map.addAttribute("msg","Please Login First..!!!");
	  return "Login";
	}
	
	//Update Student
	@PostMapping("/update")
	public String updateStudent(@SessionAttribute(value="login",required = false)AdminPojo admin,@RequestParam int id,ModelMap map) {
		StudentPojo student=services.searchStudent	(id);
		if(student!=null) {
			map.addAttribute("student",student);
			map.addAttribute("msg","Student Found");
			return "updateStudent";
		}
		map.addAttribute("msg","Sorry :( Sutdent not Found....");
		return "updateStudent";
	}
	//Update StudentData
	@PostMapping("/updateData")
	public String updateStudent(@SessionAttribute(value="login",required = false)AdminPojo admin,@RequestParam int id, @RequestParam String name, @RequestParam String email, @RequestParam long mobile, @RequestParam String address,ModelMap map ) {
		StudentPojo updateStudent=services.updateStudent(id,name,email,mobile,address);
		
		if(updateStudent!=null) {
			List<StudentPojo> students=services.allStudent();
			map.addAttribute("students",students);
			map.addAttribute("msg"," Student Updated SuccessFully!!!");
			map.addAttribute("student",updateStudent);
			return "updateStudent";
		}
		map.addAttribute("msg","Sorry :( Updation Failed!!");
		return "updateStudent";
	}
	
	
}
