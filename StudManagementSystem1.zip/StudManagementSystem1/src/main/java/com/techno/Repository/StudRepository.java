package com.techno.Repository;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.techno.POJO.StudentPojo;


@Repository
public class StudRepository {

	private static EntityManagerFactory factory;
	private static EntityManager manager;
	private static EntityTransaction transaction;
	private static Query query;
	private static String jpql;
	
	private static void openConnection() {
		factory = Persistence.createEntityManagerFactory("student");
		manager = factory.createEntityManager();
		transaction = manager.getTransaction();
	}
	
	private static void closeConnection() {
		if (factory != null) {
			factory.close();
		}
		if (manager != null) {
			manager.close();
		}
		if (transaction != null) {
			if (transaction.isActive()) {
				transaction.rollback();
			}
		}
	}

	public StudentPojo addStudent(String name, String email, long mobile, String address) {
		openConnection();
		transaction.begin();
		com.techno.POJO.StudentPojo pojo=new StudentPojo();
		pojo.setName(name);
		pojo.setEmail(email);
		pojo.setMob(mobile);
		pojo.setAddress(address);
		manager.persist(pojo);
		transaction.commit();
		closeConnection();
		return pojo;
		
	}

	public StudentPojo searchStudent(int id) {
		openConnection();
		transaction.begin();
		StudentPojo pojo=manager.find(StudentPojo.class, id);
		if(pojo !=null) {
			transaction.commit();
			closeConnection();
			return pojo;
		}
		transaction.commit();
		closeConnection();
			return null;
	}

	public StudentPojo removeStudent(int id) {
		openConnection();
		transaction.begin();
		StudentPojo pojo=manager.find(StudentPojo.class,id);
		if(pojo!=null) {
			manager.remove(pojo);
			transaction.commit();
			closeConnection();
			return pojo;
		}
		transaction.commit();
		closeConnection();
		return null;
	}

	public List<StudentPojo> allStudent() {
		openConnection();
		transaction.begin();
		jpql="from StudentPojo";
		query=manager.createQuery(jpql);
		List<StudentPojo> students=query.getResultList();
		transaction.commit();
		closeConnection();
		return students;
	}

	public StudentPojo updateStudent(int id,String name, String email, long mob, String address) {
		openConnection();
        transaction.begin();
        String jpql = "update StudentPojo s set s.name=:name, s.email=:email, s.mob=:mobile, s.address=:address where s.id=:id";
        query=manager.createQuery(jpql);
		query.setParameter("name", name);
		query.setParameter("email",email);
		query.setParameter("mobile", mob);
		query.setParameter("address", address);
		query.setParameter("id", id);
		int result=query.executeUpdate();

		transaction.commit();
		closeConnection();
		if(result!=0) {
			return searchStudent(id);
		}
		return null;
	}
}
